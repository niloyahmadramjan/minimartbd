</div> <!-- end container -->
<footer class="bg-gray-800 text-white text-center p-4 mt-10">
  &copy; <?php echo date("Y"); ?> MiniMartBD. All rights reserved.
</footer>
</body>
</html>
