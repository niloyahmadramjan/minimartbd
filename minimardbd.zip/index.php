<?php include_once("includes/header.php"); ?>
<?php include 'pages/hero_slider.php'; ?>

<h1 class="text-3xl font-bold mb-6">Welcome to MiniMartBD</h1>

<p class="mb-4">This is a sample homepage. You can add products, categories, and more here.</p>

<?php include_once("includes/footer.php"); ?>
